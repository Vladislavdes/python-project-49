### Hexlet tests and linter status:
[![Actions Status](https://github.com/Vladislavdes/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Vladislavdes/python-project-49/actions)

<a href="https://codeclimate.com/github/Vladislavdes/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/12919bc3f99eff84b809/maintainability" /></a>

<script src="https://asciinema.org/a/AmXxkFLd3nz4Uu6JlxNHuUkAm.js" id="asciicast-AmXxkFLd3nz4Uu6JlxNHuUkAm" async="true"></script>

<script src="https://asciinema.org/a/e4NXh5FUofpRNqjdAOOb1eg0p.js" id="asciicast-e4NXh5FUofpRNqjdAOOb1eg0p" async="true"></script>

<script src="https://asciinema.org/a/KXYoo60h9B1mPSRAJQA1TfIR9.js" id="asciicast-KXYoo60h9B1mPSRAJQA1TfIR9" async="true"></script>

<script src="https://asciinema.org/a/IQ8v0O0uK1uLEcP8OqPUk6dVQ.js" id="asciicast-IQ8v0O0uK1uLEcP8OqPUk6dVQ" async="true"></script>
<script src="https://asciinema.org/a/HGxmZpU7mTpgpGogngDzqaD7o.js" id="asciicast-HGxmZpU7mTpgpGogngDzqaD7o" async="true"></script>