### Hexlet tests and linter status:
[![Actions Status](https://github.com/Vladislavdes/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Vladislavdes/python-project-49/actions)

<a href="https://codeclimate.com/github/Vladislavdes/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/12919bc3f99eff84b809/maintainability" /></a>

<a href="https://asciinema.org/a/AmXxkFLd3nz4Uu6JlxNHuUkAm">brain-even</a> 

<a href='https://asciinema.org/a/e4NXh5FUofpRNqjdAOOb1eg0p'>brain-calc</a> 

<a href='https://asciinema.org/a/KXYoo60h9B1mPSRAJQA1TfIR9'>brain-gcd</a> 

<a href="https://asciinema.org/a/IQ8v0O0uK1uLEcP8OqPUk6dVQ">brain-progression</a> 

<a href='https://asciinema.org/a/HGxmZpU7mTpgpGogngDzqaD7o'>brain-prime</a>

