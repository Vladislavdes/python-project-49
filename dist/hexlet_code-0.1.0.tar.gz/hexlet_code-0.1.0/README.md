### Hexlet tests and linter status:
[![Actions Status](https://github.com/Vladislavdes/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Vladislavdes/python-project-49/actions)

<a href="https://codeclimate.com/github/Vladislavdes/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/12919bc3f99eff84b809/maintainability" /></a>

<a href='https://asciinema.org/a/e4NXh5FUofpRNqjdAOOb1eg0p'>Brain-even</a>
<a href='https://asciinema.org/a/e4NXh5FUofpRNqjdAOOb1eg0p'>Brain-calc</a>
<a href ='https://asciinema.org/a/KXYoo60h9B1mPSRAJQA1TfIR9'>Brain-gcd</a>