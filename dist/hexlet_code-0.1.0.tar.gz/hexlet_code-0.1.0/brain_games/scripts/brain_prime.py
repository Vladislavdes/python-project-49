import prompt
import random
