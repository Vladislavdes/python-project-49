#!/mnt/d/проекты/python-project-49/brain_games/scripts
def main():
    print(f'Welcome to the Brain Games!')

if __name__ == '__main__':
    main()